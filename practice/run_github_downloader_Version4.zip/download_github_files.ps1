$dest = "filepath"
New-Item -ItemType Directory -Path $dest -Force | Out-Null

Invoke-WebRequest -Uri "https://raw.githubusercontent.com/ORG/REPO/main/agilereporting/latest_snapshot.csv" -OutFile "$dest\latest_snapshot.csv"
Repeat for each

Write-Host "All files downloaded to $dest"
Pause