# ==============================
# GitHub File Downloader & Copier
# ==============================
# This script downloads files from the specified raw GitHub URLs
# and copies them to a OneDrive folder on your PC.
#
# --- How to use ---
# 1. Replace/add GitHub raw URLs in the $urls array below.
# 2. Set $oneDriveTarget to your actual OneDrive folder path.
# 3. Run this script directly or via the provided .bat file.

# --- SECTION: List your raw GitHub file URLs below ---
$urls = @(
    "https://raw.githubusercontent.com/Regnaer-Org/TestingWorkflowsOrg/main/agilereporting/latest_snapshot.csv",
    "https://raw.githubusercontent.com/Regnaer-Org/TestingWorkflowsOrg/main/agilereportingmetadata/SprintMetaData.csv",
    "https://raw.githubusercontent.com/Regnaer-Org/TestingWorkflowsOrg/main/agilereportingmetadata/issue_changelog.csv",
    "https://raw.githubusercontent.com/Regnaer-Org/TestingWorkflowsOrg/main/agilereportingmetadata/milestone_metadata.csv",
    "https://raw.githubusercontent.com/Regnaer-Org/TestingWorkflowsOrg/main/backloghealth/hierarchy_violations.csv"
    # Add more URLs as needed
)

# --- SECTION: Set your OneDrive target folder path below ---
$oneDriveTarget = "onedrivepath"  # <-- CHANGE THIS TO YOUR ACTUAL ONEDRIVE PATH

# --- Script Logic ---
$tempDownloadDir = Join-Path -Path $PSScriptRoot -ChildPath "TempGithubDownloads"
New-Item -ItemType Directory -Path $tempDownloadDir -Force | Out-Null

foreach ($url in $urls) {
    try {
        $fileName = Split-Path $url -Leaf
        $downloadPath = Join-Path -Path $tempDownloadDir -ChildPath $fileName
        Write-Host "Downloading $url..."
        Invoke-WebRequest -Uri $url -OutFile $downloadPath
    }
    catch {
        Write-Warning "Failed to download $url : $_"
    }
}

# Ensure OneDrive target exists
if (!(Test-Path -Path $oneDriveTarget)) {
    Write-Host "Creating OneDrive target folder: $oneDriveTarget"
    New-Item -ItemType Directory -Path $oneDriveTarget -Force | Out-Null
}

# Copy files to OneDrive folder
Get-ChildItem -Path $tempDownloadDir -File | ForEach-Object {
    $targetPath = Join-Path -Path $oneDriveTarget -ChildPath $_.Name
    Copy-Item -Path $_.FullName -Destination $targetPath -Force
    Write-Host "Copied $($_.Name) to $oneDriveTarget"
}

Write-Host "All files processed. Cleaning up temporary downloads."
Remove-Item -Path $tempDownloadDir -Recurse -Force

Write-Host "Done!"
Pause